package ennuo.craftworld.things;

public class InventoryItem {
    public boolean isUsedForStreaming = false;
    public int revision = 0x1A003F9;
    public Thing[] things;
    public InventoryMetadata metadata;
}
