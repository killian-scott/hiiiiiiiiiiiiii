package ennuo.craftworld.things;

public class ThingPtr {
    public boolean isPart = false;
    public int UID = -1;
    public int index = -1; 
    public Part part = null;
    public Thing thing = null;
}
